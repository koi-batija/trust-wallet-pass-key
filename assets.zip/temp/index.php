<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Live Temp Mail</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
  <style>
    body {
      background: #f0f4f8;
    }
    .card {
      background: white;
      border-radius: 1rem;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
    }
  </style>
</head>
<body class="min-h-screen flex items-center justify-center p-6">
  <div class="w-full max-w-3xl card p-6">
    <h1 class="text-3xl font-bold text-center mb-6 text-indigo-700">📧 Live Temp Mail</h1>

    <div class="flex justify-center mb-4">
      <button onclick="createEmail()" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2 px-4 rounded-xl transition">
        ➕ Generate New Email
      </button>
    </div>

    <div class="text-center text-gray-700 mb-4">
      <strong>Current Email:</strong>
      <span id="emailDisplay" class="text-indigo-600 font-mono"></span>
    </div>

    <div class="mt-6">
      <h2 class="text-xl font-semibold mb-3 text-gray-800">📥 Inbox</h2>
      <div id="inbox" class="space-y-4 max-h-96 overflow-y-auto border-t pt-3"></div>
    </div>
  </div>

  <script>
    let currentEmail = localStorage.getItem("tempMailEmail") || "";

    window.onload = () => {
      if (currentEmail) {
        document.getElementById("emailDisplay").innerText = currentEmail;
        loadInbox();
        setInterval(loadInbox, 10000);
      }
    };

    function createEmail() {
      fetch("create_email.php")
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            currentEmail = data.email;
            localStorage.setItem("tempMailEmail", currentEmail);
            document.getElementById("emailDisplay").innerText = currentEmail;
            loadInbox();
            setInterval(loadInbox, 10000);
          } else {
            alert("Email creation failed: " + data.error);
          }
        });
    }

    function loadInbox() {
      if (!currentEmail) return;
      fetch("get_mails.php?email=" + encodeURIComponent(currentEmail))
        .then(res => res.json())
        .then(mails => {
          const inbox = document.getElementById("inbox");
          inbox.innerHTML = mails.length
            ? mails.map(mail => `
              <div class="p-4 bg-gray-50 rounded-lg border border-gray-200">
                <div class="text-sm text-gray-500 mb-1"><strong>From:</strong> ${mail.from}</div>
                <div class="text-md font-bold text-gray-800">${mail.subject}</div>
                <div class="mt-2 text-gray-700 whitespace-pre-wrap">${mail.body}</div>
              </div>
            `).join('')
            : "<p class='text-gray-500 italic'>No messages yet...</p>";
        });
    }
  </script>
</body>
</html>
