<?php
header('Content-Type: application/json');

// CONFIG - Update kore neben
$cpanel_user = "wecfoyij";
$cpanel_token = "2XCKXRORVGO3JN5H8004VOE40S1VGU0L";
$domain = "startravelagencybd.xyz";             // domain name

// Email generate
$random = substr(md5(uniqid()), 0, 6);
$email_user = "temp_$random";
$email_pass = "TempP@ss123"; // ektu strong password use korben porer jonno
$email_full = "$email_user@$domain";

// cPanel API URL
$url = "https://$domain:2083/json-api/cpanel?cpanel_jsonapi_user=$cpanel_user&cpanel_jsonapi_apiversion=2&cpanel_jsonapi_module=Email&cpanel_jsonapi_func=addpop&domain=$domain&email=$email_user&password=$email_pass&quota=20";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    "Authorization: cpanel $cpanel_user:$cpanel_token"
]);

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_error = curl_error($ch);
curl_close($ch);

if ($curl_error) {
    echo json_encode([
        "success" => false,
        "error" => "Curl error: $curl_error"
    ]);
    exit;
}

if ($http_code !== 200) {
    echo json_encode([
        "success" => false,
        "error" => "HTTP error code: $http_code",
        "response" => $response
    ]);
    exit;
}

// Decode response for further checking
$data = json_decode($response, true);

if (!$data) {
    echo json_encode([
        "success" => false,
        "error" => "Invalid JSON response",
        "raw_response" => $response
    ]);
    exit;
}

// Check for cPanel success in response (depends on API)
if (isset($data['cpanelresult']['data'][0]['result']) && $data['cpanelresult']['data'][0]['result'] == 1) {
    // Success - optionally save credentials if you want
    if (!file_exists("emails")) mkdir("emails");
    file_put_contents("emails/$email_full.json", json_encode([
        "email" => $email_full,
        "password" => $email_pass
    ]));

    echo json_encode([
        "success" => true,
        "email" => $email_full
    ]);
} else {
    $msg = isset($data['cpanelresult']['data'][0]['reason']) ? $data['cpanelresult']['data'][0]['reason'] : 'Unknown error from cPanel API';
    echo json_encode([
        "success" => false,
        "error" => $msg,
        "response" => $data
    ]);
}
