<?php
header('Content-Type: application/json');

$email = $_GET['email'] ?? '';
if (!$email) {
    echo json_encode([]);
    exit;
}

// Email credentials (password gulo file/DB theke nite paren)
$credentialsFile = __DIR__ . '/emails/' . $email . '.json';
if (!file_exists($credentialsFile)) {
    echo json_encode([]);
    exit;
}

$creds = json_decode(file_get_contents($credentialsFile), true);
if (!$creds) {
    echo json_encode([]);
    exit;
}

$username = $email;
$password = $creds['password'];

// IMAP server info
// Apnar cPanel mail server er IMAP host & port thik kore deben
$imapServer = '{mail.startravelagencybd.xyz:993/imap/ssl}INBOX';


$inbox = imap_open($imapServer, $username, $password);
if (!$inbox) {
    echo json_encode(['error' => 'Cannot connect to mailbox: ' . imap_last_error()]);
    exit;
}

$emails = imap_search($inbox, 'ALL');
$mails = [];

if ($emails) {
    rsort($emails);
    foreach ($emails as $email_number) {
        $overview = imap_fetch_overview($inbox, $email_number, 0)[0];
        $message = imap_fetchbody($inbox, $email_number, 1);
        $mails[] = [
            'from' => $overview->from,
            'subject' => $overview->subject,
            'body' => quoted_printable_decode($message),
            'date' => $overview->date,
        ];
    }
}

imap_close($inbox);

echo json_encode($mails);
